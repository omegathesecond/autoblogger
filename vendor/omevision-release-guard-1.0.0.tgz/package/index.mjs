import fs from 'node:fs/promises';
import path from 'node:path';
import {gunzipSync,brotliDecompressSync} from 'node:zlib';
export const retiredDomain=['vavu','app'].join('.');
const excludedDirs=new Set(['.git','node_modules','vendor','docs','deployments','tests','test','__tests__','.release-tools','.release-artifacts']);
export class ReleaseGuardError extends Error { constructor(message){super(message);this.name='ReleaseGuardError';} }
export function assertClean(value,label){
 let text=Buffer.isBuffer(value)?value.toString('utf8'):String(value);
 for(let pass=0;pass<4;pass++){
  if(text.toLowerCase().includes(retiredDomain))throw new ReleaseGuardError(`Retired domain ${retiredDomain} found in ${label}. Use yeboshops.com. Values are redacted.`);
  const decoded=text.replace(/\\u([0-9a-f]{4})/gi,(_,n)=>String.fromCharCode(parseInt(n,16))).replace(/\\x([0-9a-f]{2})/gi,(_,n)=>String.fromCharCode(parseInt(n,16))).replace(/&#(?:x([0-9a-f]+)|(\d+));?/gi,(_,h,d)=>String.fromCodePoint(parseInt(h||d,h?16:10))).replace(/&period;|&dot;/gi,'.').replace(/%([0-9a-f]{2})/gi,(_,n)=>String.fromCharCode(parseInt(n,16))).replace(/\\\./g,'.');
  if(decoded===text)break;text=decoded;
 }
}
export function checkEnvironment(env=process.env){for(const [name,value]of Object.entries(env))if(value!==undefined)assertClean(value,`environment variable ${name}`);}
export async function scanPaths(root,paths,{source=false}={}){
 let files=0;
 async function visit(file){
  const relative=path.relative(root,file).split(path.sep).join('/');assertClean(relative,'release file name');
  const info=await fs.lstat(file);if(info.isSymbolicLink())throw new ReleaseGuardError(`Cannot verify symbolic link ${relative}; release inputs must be regular files.`);
  if(info.isDirectory()){
   if(source&&excludedDirs.has(path.basename(file)))return;
   for(const entry of await fs.readdir(file))await visit(path.join(file,entry));return;
  }
  if(!info.isFile())throw new ReleaseGuardError(`Cannot verify non-file input ${relative}`);
  if(source&&(/(?:\.test|\.spec)\.[^/]+$/.test(relative)||/\.(md|mdx|log)$/.test(relative)))return;
  let data=await fs.readFile(file);assertClean(data,relative);
  if(file.endsWith('.gz')||file.endsWith('.tgz'))assertClean(gunzipSync(data),`${relative} (decompressed)`);
  if(file.endsWith('.br'))assertClean(brotliDecompressSync(data),`${relative} (decompressed)`);
  files++;
 }
 for(const selected of paths)await visit(path.resolve(root,selected));return files;
}
export async function verify({root=process.cwd(),phase='source',paths=[],environment=process.env}={}){
 checkEnvironment(environment);let config;
 if(!paths.length||phase==='deploy'){
  const manifest=await fs.readFile(path.join(root,'.release-guard.json'),'utf8');assertClean(manifest,'release guard manifest');config=JSON.parse(manifest);
  if(config.version!==1||!Array.isArray(config.sources)||!Array.isArray(config.artifacts)||!config.sources.length||!config.artifacts.length)throw new ReleaseGuardError('Invalid release guard manifest');
 }
 let files=0;
 if(phase==='runtime')for(const file of ['.env','.env.production','.env.local','.env.production.local']){try{await fs.lstat(path.join(root,file));}catch(error){if(error.code==='ENOENT')continue;throw error;}files+=await scanPaths(root,[file]);}
 if(phase==='source'||phase==='deploy')files+=await scanPaths(root,config?.sources||paths,{source:true});
 if(phase!=='source')files+=await scanPaths(root,paths.length?paths:config.artifacts);
 return {files,phase};
}
