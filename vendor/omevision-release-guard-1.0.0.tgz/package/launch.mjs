import {spawn} from 'node:child_process';
import {constants} from 'node:os';
import {verify,assertClean} from './index.mjs';
try{
 for(let i=2;i<process.argv.length;i++)assertClean(process.argv[i],`runtime command argument ${i-2}`);
 await verify({phase:'runtime'});const [command,...args]=process.argv.slice(2);if(!command)throw new Error('A runtime command is required');
 const child=spawn(command,args,{stdio:'inherit'});
 for(const signal of ['SIGTERM','SIGINT','SIGHUP'])process.on(signal,()=>child.kill(signal));
 child.on('error',error=>{console.error(error.message);process.exitCode=1;});
 child.on('exit',(code,signal)=>{process.exitCode=code??(128+(constants.signals[signal]||1));});
}catch(error){console.error(`${error.name}: ${error.message}`);process.exitCode=1;}
