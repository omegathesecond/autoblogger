# Omevision release guard

The canonical implementation lives here; consumers vendor the npm archive. It rejects the retired marketplace domain in active source/configuration, generated files (including gzip/Brotli), and effective build/runtime environment values. Errors identify files or variable names and redact values. Missing/unreadable release inputs fail verification.

`node node_modules/@omevision/release-guard/cli.mjs --phase source` checks the manifest's active inputs. `--path dist --phase artifacts` checks the complete artifact, including source maps. `--phase deploy --path dist -- command` verifies inputs and output before invoking a deployment. The Vite plugin also enforces checks when Vite is invoked directly. Container entrypoints verify artifacts and resolved environment bindings before starting the existing command, forwarding shutdown signals and exit status.

Documentation, archived deployment evidence, dependencies and test fixtures are excluded from source checks; artifacts have no such exclusions. Release checks do not rewrite or silently substitute URLs. Provider administrators can bypass repository tooling by invoking provider APIs directly; these checks protect the configured release paths.
