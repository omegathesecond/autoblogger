import path from 'node:path';
import {assertClean,checkEnvironment,verify,scanPaths} from './index.mjs';
export function releaseGuard(){let root,outDir;return {
 name:'omevision-release-guard',enforce:'post',apply:'build',
 async configResolved(config){root=process.cwd();outDir=path.resolve(config.root,config.build.outDir);await verify({root});for(const [name,value]of Object.entries(config.env))assertClean(value,`Vite environment ${name}`);checkEnvironment();},
 generateBundle(_options,bundle){for(const [name,entry]of Object.entries(bundle)){assertClean(name,'generated asset name');assertClean(entry.type==='chunk'?entry.code:entry.source,`generated asset ${name}`);}},
 closeBundle:{order:'post',async handler(){await scanPaths(root,[outDir]);}}
};}
