export declare function releaseGuard(): import('vite').Plugin;
