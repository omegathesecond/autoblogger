#!/usr/bin/env node
import {spawn} from 'node:child_process';
import {verify,assertClean,ReleaseGuardError} from './index.mjs';
const args=process.argv.slice(2),separator=args.indexOf('--'),command=separator<0?[]:args.splice(separator).slice(1);let phase='source',root=process.cwd(),paths=[];
try{
 for(let i=0;i<args.length;i++){
  const arg=args[i];if(arg==='--phase')phase=args[++i];else if(arg==='--root')root=args[++i];else if(arg==='--path')paths.push(args[++i]);else throw new ReleaseGuardError('Unknown release guard option');
 }
 if(!['source','artifacts','runtime','deploy'].includes(phase)||paths.some(x=>!x)||!root)throw new ReleaseGuardError('Invalid release guard arguments');
 for(let i=0;i<command.length;i++)assertClean(command[i],`release command argument ${i}`);
 const result=await verify({root,phase,paths});console.log(`Release guard passed: ${result.files} files (${phase}).`);
 if(command.length){const child=spawn(command[0],command.slice(1),{stdio:'inherit'});child.on('error',error=>{console.error(error.message);process.exitCode=1;});child.on('exit',(code,signal)=>{process.exitCode=code??(signal?1:0);});}
}catch(error){console.error(`${error.name}: ${error.message}`);process.exitCode=1;}
